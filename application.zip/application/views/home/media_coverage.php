<section class="hero bg-cover bg-position py-4" style="background: url(<?php echo base_url('assets/');?>img/hero-banner-3.jpg)">
      <div class="container py-5 index-forward text-white">
        <h1>Media Coverage</h1>
        <!-- Breadcrumb-->
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb bg-none mb-0 p-0">
            <li class="breadcrumb-item pl-0"><a href="<?php echo base_url();?>"> <i class="fas fa-home mr-2"></i>Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Media Coverage</li>
          </ol>
        </nav>
      </div>
    </section>
    <section class="py-5 shadow-sm index-forward">
      <div class="container py-5">
        <div class="row">
          <div class="col-lg-8">
           <div class="card shadow">
             <div class="card-body">
              <img src="https://www.rajnathsingh.in/wp-content/uploads/2019/12/Raksha-Mantri-Shri-Rajnath-Singh-statement-on-Rahul-Gandhis-contoversial-statement-on-rape-on-13-december-825x510.jpg" width="100%">
              <h3 class="text-primary pt-3">Media Covarage Title Goes Here</h3>
              <p class="text-justify">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perspiciatis optio minus quam earum, nesciunt eaque inventore non obcaecati. Minus cupiditate perferendis alias ipsa voluptates cum sed accusantium soluta aperiam nihil.</p>
             </div>
           </div>
          </div>
          <div class="col-lg-4">
           <div class="card">
            <div class="card-header text-white bg-primary">
              Categories
            </div>
             <div class="card-body p-0">
               <ul style="list-style: none;font-weight: bold;">
                 <li><a href="#" style="text-decoration: none;padding: 5px;" >Achievements 1</a></li>
                 <li><a href="#" style="text-decoration: none;padding: 5px;" >Achievements 2</a></li>
                 <li><a href="#" style="text-decoration: none;padding: 5px;" >Achievements 3</a></li>
                 <li><a href="#" style="text-decoration: none;padding: 5px;" >Achievements 4</a></li>
                 <li><a href="#" style="text-decoration: none;padding: 5px;" >Achievements 5</a></li>
               </ul>
             </div>

           </div>
          </div>
        </div>
      </div>
    </section>